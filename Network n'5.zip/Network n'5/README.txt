Shape Generator

Generatore casuale di forme geomentriche e linee attivabile tramite comando tastiera

Tutorial:https://youtu.be/vzi-ktOsxJo
Autore: Bileam Tschepe