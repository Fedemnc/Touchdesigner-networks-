Nvidial Flex


Creazione di cubo a base particellare scalabile 

Tutorial: https://youtu.be/keVyiCBHWhI
Autore: The interactive & Immersive HQ