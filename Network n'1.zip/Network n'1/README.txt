Nvidia Flow 

Creazione di bastoni fluorescenti e incendiati 

Tutorial: https://www.youtube.com/watch?v=AYOwAZXin_Y
Autore: Maurizio Orlando
