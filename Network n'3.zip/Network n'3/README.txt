Aura audio spectrum 

In questo esercizio ho deciso di ricreare un ambiemte sonoro utilizzando l'audio spectrum
unendo modifiche al noise principale.
Durante la lavorazione mi sono ispirato molto anche alle macchie di Rorschach al fine di riprodurne 
una mia versione unita all'elemento acqua, uniti creano questa visione quasi subacquea ed ipnotica.
Ho deciso in oltre di usare la traccia dei Nine Icht Nail 'out in the open' come punto di riferimento sonoro 
che a mio parere risulta ottima per valorizzare al meglio le senzazioni date dal questa proposta di visual


Tutorial: https://youtu.be/NJE48IVzNVc
Autore: Bileam Tschepe