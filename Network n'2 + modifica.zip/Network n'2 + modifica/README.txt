Looping Noise + Modifica

Il secondo esercizio consiste nel ricreare un looping noise particellare con l'aggiunta di una geomentria creata circolare 
inserita sempre con un comando di looping, 
che agisce in contemporanea sul noise particellare già applicato in modo da creare un effetto echo sulla superficie.

Per fare ciò, ho creato un una geolmetria 'circle' unita ad un nodo 'ramp'.
una volta fatto questo entrando nella sezione <CHOP> ho applicato un 'lookup' un canale 'null' per poi applicare il valore di quest'ultimo ad un secondo'noise',
entrambe collegate tra di loro tramite un secondo 'null'.

Tutorial: https://www.youtube.com/watch?v=TGYO1WcT5ys
Autore: Simon Alexander-Adams